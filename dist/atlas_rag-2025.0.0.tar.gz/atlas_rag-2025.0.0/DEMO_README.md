# AutoSchemaKG
This repository is the official implementation of the paper [*AutoSchemaKG: Autonomous Knowledge Graph Construction through Dynamic Schema Induction from Web-Scale Corpora*](https://arxiv.org/abs/2505.23628).


## Todo

- [ ] We are working on the link of our full KG data.
- [ ] We are working on restructuring the code for easier replication of results
- [ ] We are working on demo and tutorials for easier end-to-end RAG with our framework

## Quickstart
Here we provide a simple demo to construct KG from a plain text with the same method in our AutoSchemaKG.

(Remenber to replace your own file name while implementing the following steps.)

### Step 1: Triple extraction

The document to be extracted has been placed in `./tests/Dulce.json`. You can also replace it with your own corpus with the same format.

Then, run the following command to extract triples:
```shell
cd ./src/LKGConstruction/script

sh triple_extraction_demo.sh
```

And you can obtain your generation result under `./tests/generation_result/Dulce/`.

### Step 2: Json to CSV
Transform the json file obtained in step 1 to csv files.
```shell
sh json2csv_demo_with_text.sh
```
And you can have your KG files with csv format under `./src/LKGConstruction/import`.

## Step 3: Conceptualization
Then conceptualize the KG we have extracted with the command:
```shell
sh concept_generation_demo.sh

sh merge_demo_concept.sh
```

## Step 4: Load Concept to CSV
```shell
sh concept_to_csv_demo.sh
```
Now you can find your final KG with concepts under `./src/LKGConstruction/import`.

## Step 5: Query on AutoSchemaKG

### Option 1 [NetworkX]:
You can load the KG to NetworkX from `./src/LKGConstruction/import` and query any node or relation with the command:
```shell
sh query_on_networkx.sh
```

For example, you can query with the node *"Jordan Hayes"* and obtain all its neighbors (including entity, event, concept and original text) like:

```json
[
    {
        "name:ID": "Mercer",
        "type": "entity",
        "concepts": "[]",
        "synsets": "[]",
        ":LABEL": "Node"
    },
    {
        "name:ID": "stepping closer towards the volatile embrace of Operation: Dulce",
        "type": "event",
        "concepts": "[]",
        "synsets": "[]",
        ":LABEL": "Node"
    },
    {
        "concept_id:ID": 
        "e9b52e83a2497e9656a7b6030ddf5175d54c4f991cacebd04f074ae42e103c3e",
        "name": "person",
        ":LABEL": "Concept"
    },
    {
        "text_id:ID": "d7d045db7baae0f6d60ed56b0123cd3a2cd67cddede6f27401d552bd73efa969",
        "original_text": "# Operation: Dulce\n\n## Chapter 1\n\nThe thrumming of monitors ...",
        ":LABEL": "Text"
    }
]
```

### Option 2 [Neo4j]:
We also provide scripts to establish a Neo4j server with your generated KG.

```shell
# Download and install Neo4j server
sh get_neo4j_demo.sh
```

Load your generated KG to Neo4j:
```shell
# Stop Neo4j if running
../neo4j-server-dulce/bin/neo4j stop

# Load the CSV files into Neo4j
../neo4j-server-dulce/bin/neo4j-admin database import full dulce-csv-json-text \
    --nodes=../import/text_nodes_dulce_llama3_8b_1_in_1_from_json.csv \
    ../import/triple_nodes_dulce_llama3_8b_1_in_1_from_json_without_emb.csv \
    ../import/concept_nodes_dulce_llama3_8b_1_in_1_from_json_without_emb.csv \
    --relationships=../import/text_edges_dulce_llama3_8b_1_in_1_from_json.csv \
    ../import/triple_edges_dulce_llama3_8b_1_in_1_from_json_without_emb_full_concept.csv \
    ../import/concept_edges_dulce_llama3_8b_1_in_1_from_json_without_emb.csv \
    --overwrite-destination \
    --multiline-fields=true \
    --id-type=string \
    --verbose --skip-bad-relationships=true
```

Then you can start your Neo4j server: 
```shell
# Start Neo4j server
sh start_neo4j_demo.sh
```



## Citation

```
@misc{bai2025autoschemakgautonomousknowledgegraph,
      title={AutoSchemaKG: Autonomous Knowledge Graph Construction through Dynamic Schema Induction from Web-Scale Corpora}, 
      author={Jiaxin Bai and Wei Fan and Qi Hu and Qing Zong and Chunyang Li and Hong Ting Tsang and Hongyu Luo and Yauwai Yim and Haoyu Huang and Xiao Zhou and Feng Qin and Tianshi Zheng and Xi Peng and Xin Yao and Huiwen Yang and Leijie Wu and Yi Ji and Gong Zhang and Renhai Chen and Yangqiu Song},
      year={2025},
      eprint={2505.23628},
      archivePrefix={arXiv},
      primaryClass={cs.CL},
      url={https://arxiv.org/abs/2505.23628}, 
}
```


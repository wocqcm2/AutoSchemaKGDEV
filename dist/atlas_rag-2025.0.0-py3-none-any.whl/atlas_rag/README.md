# Guide for Running the code
Conda install with the given environment.yaml file.
## Multihop QA
Proceed to AutoSchemaKGConstruction for KG construction

Then proceed to ATLASMultiHopQA for reproducing result in multihop qa.
## General QA
Proceed to LKGConstruction for database construction

Then Proceed to ATLASRetriever for hosting ATLASRetriever.